<?php defined( 'ABSPATH' ) or die( "Cannot access pages directly." );

?>


<div class="wcop_sp_section_heading whcom_bg_primary whcom_text_white">
	<i class="whcom_icon_ticket"></i>
	<span><?php esc_html_e( "Enter a Coupon Code", "whcom" ) ?></span>
</div>
<div class="wcop_sp_section_content">


</div>




