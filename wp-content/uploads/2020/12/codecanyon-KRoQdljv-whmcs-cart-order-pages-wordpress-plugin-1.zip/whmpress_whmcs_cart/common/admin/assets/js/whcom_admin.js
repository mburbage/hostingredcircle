/**
 * Created by Abdul Waheed on 07-Aug-17.
 */
(function ( $ ) {
	$('.whcom_color_input').wpColorPicker();
}(jQuery));