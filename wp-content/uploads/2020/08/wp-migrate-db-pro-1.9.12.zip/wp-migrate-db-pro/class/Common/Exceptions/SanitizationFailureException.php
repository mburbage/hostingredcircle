<?php

namespace DeliciousBrains\WPMDB\Common\Exceptions;

class SanitizationFailureException extends \UnexpectedValueException
{

}
