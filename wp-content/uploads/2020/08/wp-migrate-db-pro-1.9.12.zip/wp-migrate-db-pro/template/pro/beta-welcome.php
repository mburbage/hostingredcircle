<div class="below-title beta-welcome warning inline-message">
	<strong>Thanks for trying out our beta!</strong>
	<p>
		If you have any questions about the beta or if you have any feedback at all, let us know. Any little bit you're willing to share helps. Click
		<a href="#help" onclick="jQuery('.wrap.wpmdb > h2 > a.nav-tab.js-action-link.help').trigger('click'); return false;">here</a> or on the Help tab to use our support form to send us your feedback &amp; questions.
	</p>
	<p>
		<?php
		/* translators: 1: Remind Me Later, 2: Dismiss */
		echo $dismiss;
		?>
	</p>
</div>
